sap.ui.define([
    "sap/ui/model/json/JSONModel",
    "sap/ui/model/xml/XMLModel"
], function(JSONModel, XMLModel) {
    'use strict';
    return {
        createJSONModel: function(){
            //Step 1: Create a brand new model object
            var oModel = new JSONModel();
            //Step 2: Set the data to the model
            //oModel.setData();
            oModel.loadData("model/mockdata/sample.json");
            return oModel;
        },
        createXMLModel: function(){
            //Step 1: Create a brand new model object
            var oModel = new XMLModel();
            //Step 2: Set the data to the model
            //oModel.setData();
            oModel.loadData("model/mockdata/mydata.xml");
            return oModel;
        },
        createResourceModel: function(){

        }

    };

});