//AMD - Asynchronous module definition
sap.ui.define(
            ["sap/ui/core/mvc/Controller",
            "mickey/model/models"], 
            function(Controller, models){
                return Controller.extend("mickey.controller.Main",{
                    //constructor
                    onInit: function(){
                        //alert('object ban gaya');
                        this.oView = this.getView();
                        //Create JSON model - client Side model
                        var oModel = models.createJSONModel();  
                        //Create XML model - client Side model
                        var oModelXML = models.createXMLModel();
                        //Step 3: make the model aware to the application
                        var oApplication = sap.ui.getCore();

                        //Set JSON Model to App --Anubhav
                        //Without name - default model
                        oApplication.setModel(oModel); 
                        //Set XML Model to the App -- Surender
                        //Named model concept
                        oApplication.setModel(oModelXML, "yui");
                        //Get object of salary field
                        var oSal = this.getView().byId("idSal");
                        //Perform bining using Syntax option 3
                        oSal.bindValue("/empStr/salary");

                        //Get object of Currency -  using Syntax option 4
                        var oCurr = this.getView().byId("idCurr");
                        //Perform bining 
                        oCurr.bindProperty("value","/empStr/currency");

                    },
                    
                    onClick: function(){
                        //Step 1: Get the object of the view - control is inside the view
                        //this pointer like ME, which points to current class
                        //var oView = this.getView();
                        //Step 2: get the control object from the view
                        var oBtn = this.oView.byId("idBtn");
                        //Step 3: We can call UI5 functions available in SDK
                        oBtn.setText("Maza Avvigiyo");
                        oBtn.setEnabled(false);
                        //alert('code trigger ho gaya');
                        //this.getView().byId("idBtn").setText("Chora toh cool hai");
                    },
                    onSet: function(){
                        //Step 1: get the model object
                        var oModel = sap.ui.getCore().getModel();
                        //Step 2: set data
                        oModel.setProperty("/empStr/empName","Rock is cooking!");
                    },
                    onPrint: function(){

                        //Access the data via model
                        //Step 1: get the model object
                        var oModel = sap.ui.getCore().getModel();
                        //Step 2: get data from model to print
                        var data = oModel.getProperty("/empStr");
                        
                        console.log(data);

                        // //Step 1: Get the object of our View
                        // //var oView = this.getView();
                        // //Step 2: Get the Object field
                        // var oEmpId = this.oView.byId("idEmpId");
                        // var oEmpName = this.oView.byId("idEmpName");
                        // var oEmpSalary = this.oView.byId("idSal");
                        // var oEmpCurr = this.oView.byId("idCurr");
                        // //Step 3: Print data
                        // console.log(oEmpId.getValue() + "," + 
                        // oEmpName.getValue() + "," +
                        // oEmpSalary.getValue() + "," +
                        // oEmpCurr.getValue() );
                        
                    },
                    onBeforeRendering: function(){
                        this.getView().byId("idBtn").setIcon("sap-icon://supplier");
                    },
                    onAfterRendering: function(){
                        $("#idMain--idBtn").fadeOut(3000, function(){
                            $("#idMain--idBtn").fadeIn(3000);
                        });
                    }
                });
});