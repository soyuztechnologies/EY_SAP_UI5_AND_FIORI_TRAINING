sap.ui.define([
    'ey/fin/ar/controller/BaseController',
    'sap/m/MessageBox'
], function(Controller, MessageBox) {
    'use strict';
    return Controller.extend("ey.fin.ar.controller.View1",{
        
        onNext: function(){
            this.printX();
            //Step 1: get the parent object - container
            var oAppCon = this.getView().getParent();
            //Step 2: navigate to the second view
            oAppCon.to("idView2");
        },
        onClick: function(){
            //alert('order has been patched');
            MessageBox.information("Your order has been placed successfully",{
                title: "Information"
            });
            this.onNext();
        }
    });
});