sap.ui.define([
    'ey/fin/ar/controller/BaseController'
], function(Controller) {
    'use strict';
    return Controller.extend("ey.fin.ar.controller.View2",{
        
        onBack: function(){
            this.printX();
            //Step 1: get the parent object - container
            var oAppCon = this.getView().getParent();
            //Step 2: navigate to the second view
            oAppCon.to("idView1");
        }
    });
});