sap.ui.define([
    'ey/fin/ar/controller/BaseController'
], function(Controller) {
    'use strict';
    return Controller.extend("ey.fin.ar.controller.App",{

    });
});