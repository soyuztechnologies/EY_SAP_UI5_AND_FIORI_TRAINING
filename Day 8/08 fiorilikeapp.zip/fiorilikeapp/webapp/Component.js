sap.ui.define([
    'sap/ui/core/UIComponent'
], function(UIComponent) {
    'use strict';
    return UIComponent.extend("ey.fin.ar.Component",{
        metadata: {
            manifest: "json"
        },
        init: function(){
            //initialize parent class constructor
            UIComponent.prototype.init.apply(this);
        },
        createContent: function(){
            var oAppView = new sap.ui.view("idApp",{
                viewName: "ey.fin.ar.view.App",
                type: "XML"
            });

            //Create object of our views
            var oView1 = new sap.ui.view("idView1",{
                viewName: "ey.fin.ar.view.View1",
                type: "XML"
            });
            var oView2 = new sap.ui.view("idView2",{
                viewName: "ey.fin.ar.view.View2",
                type: "XML"
            });

            //Get the App Container object
            var oAppCon = oAppView.byId("appCon");
            //We will add our views inside
            oAppCon.addPage(oView1).addPage(oView2);

            return oAppView;
        },
        destroy: function(){

        }
    });
});