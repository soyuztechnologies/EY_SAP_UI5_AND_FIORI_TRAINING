sap.ui.define([
    'ey/fin/ar/controller/BaseController',
    'sap/m/MessageBox',
    'sap/m/MessageToast'
], function(Controller, MessageBox, MessageToast) {
    'use strict';
    return Controller.extend("ey.fin.ar.controller.View2",{
        onInit : function(){
            this.oRouter = this.getOwnerComponent().getRouter();
            this.oRouter.getRoute("detail").attachMatched(this.herculis, this);
        },
        onSupplierItem: function(oEvent){
            var oSelectItem = oEvent.getParameter("listItem");
            var sPath = oSelectItem.getBindingContextPath();
            console.log(sPath);

            //get the index of selected supplier
            var sIndex = sPath.split("/")[sPath.split("/").length - 1];
            //call the router to navigate to 3rd view
            this.oRouter.navTo("supplier",{
                supplierId: sIndex
            });

        },
        onSave: function(){
            MessageBox.confirm("Would you like to save?",{
                title:"Confirmation",
                onClose: function(status){
                    if(status === "OK"){
                        MessageToast.show("Your order has been placed");
                    }else{
                        MessageBox.error("Save has been cancelled");
                    }
                }
            });
        },

        //Route Matched handler function
        herculis: function(oEvent){
            var sIndex = oEvent.getParameter("arguments").fruitId;
            var sPath = '/fruits/' + sIndex;
            this.getView().bindElement(sPath);
            //debugger;
        },
        onBack: function(){
            this.printX();
            //Step 1: get the parent object - container
            var oAppCon = this.getView().getParent();
            //Step 2: navigate to the second view
            oAppCon.to("idView1");
        }
    });
});