sap.ui.define([
    "sap/ui/core/format/NumberFormat"
], function(NumberFormat) {
    'use strict';
    return {
        convertToCaps: function(inp){
            if(inp){
                return inp.toUpperCase();
            }
        },
        formatSalary: function(salary, currency){
            var oCurrencyFormat = NumberFormat.getCurrencyInstance({
                currencyCode: false
            });

            return oCurrencyFormat.format(salary, currency); // output: EUR 12,345.68
        }
    };
});