//AMD - Asynchronous module definition
sap.ui.define(
            ["sap/ui/core/mvc/Controller",
            "mickey/model/models",
            "mickey/util/lifeSaver"], 
            function(Controller, models, lifeSaver){
                return Controller.extend("mickey.controller.Main",{
                    //constructor
                    //global variable accessible by all functions of our controller
                    formatter: lifeSaver,
                    oApplication: sap.ui.getCore(),
                    onInit: function(){
                        //alert('object ban gaya');
                        this.oView = this.getView();
                        //Create JSON model - client Side model
                        var oModel = models.createJSONModel();  
                        //Create XML model - client Side model
                        var oModelXML = models.createXMLModel();
                        //Create Resource model - client Side model
                        var oResource = models.createResourceModel();
                        //Step 3: make the model aware to the application
                        //var oApplication = sap.ui.getCore();

                        //Set JSON Model to App --Anubhav
                        //Without name - default model
                        this.oApplication.setModel(oModel); 
                        //Set XML Model to the App -- Surender
                        //Named model concept
                        this.oApplication.setModel(oModelXML, "yui");

                        //Set Resource Model to the App -- all labels
                        //Named model concept
                        this.oApplication.setModel(oResource, "i18n");

                        //Get object of salary field
                        var oSal = this.getView().byId("idSal");
                        //Perform bining using Syntax option 3
                        //oSal.bindValue("/empStr/salary");

                        //Get object of Currency -  using Syntax option 4
                        var oCurr = this.getView().byId("idCurr");
                        //Perform bining 
                        //oCurr.bindProperty("value","/empStr/currency");

                    },
                    onRowSelect: function(oEvent){
                        //oEvent - Free object you will receive out-of-box, this will carry important
                        //         information about our event
                        //Now know which element was select
                        //Step 1: What is the location of the memory of the data which is selected
                        var sElementAddress = oEvent.getParameter("rowContext").getPath();
                        console.log(sElementAddress);

                        //Step 2: get The object of the simple form
                        var oSimple = this.getView().byId("idSuperman");

                        //Step 3: Perform element binding
                        oSimple.bindElement(sElementAddress);

                        //debugger;
                    },
                    
                    onSwitch: function(){
                        //Get The model objects
                        var oModel = this.oApplication.getModel();
                        var oModelYui = this.oApplication.getModel("yui");
                        //Interchange them
                        this.oApplication.setModel(oModelYui);
                        this.oApplication.setModel(oModel, "yui");
                    },

                    onClick: function(){
                        //Step 1: Get the object of the view - control is inside the view
                        //this pointer like ME, which points to current class
                        //var oView = this.getView();
                        //Step 2: get the control object from the view
                        var oBtn = this.oView.byId("idBtn");
                        //Step 3: We can call UI5 functions available in SDK
                        oBtn.setText("Maza Avvigiyo");
                        oBtn.setEnabled(false);
                        //alert('code trigger ho gaya');
                        //this.getView().byId("idBtn").setText("Chora toh cool hai");
                    },
                    onSet: function(){
                        //Step 1: get the model object
                        var oModel = sap.ui.getCore().getModel();
                        //Step 2: set data
                        oModel.setProperty("/empStr/empName","Rock is cooking!");
                    },
                    onPrint: function(){

                        //Access the data via model
                        //Step 1: get the model object
                        var oModel = sap.ui.getCore().getModel();
                        //Step 2: get data from model to print
                        var data = oModel.getProperty("/empStr");
                        
                        console.log(data);

                        // //Step 1: Get the object of our View
                        // //var oView = this.getView();
                        // //Step 2: Get the Object field
                        // var oEmpId = this.oView.byId("idEmpId");
                        // var oEmpName = this.oView.byId("idEmpName");
                        // var oEmpSalary = this.oView.byId("idSal");
                        // var oEmpCurr = this.oView.byId("idCurr");
                        // //Step 3: Print data
                        // console.log(oEmpId.getValue() + "," + 
                        // oEmpName.getValue() + "," +
                        // oEmpSalary.getValue() + "," +
                        // oEmpCurr.getValue() );
                        
                    },
                    onBeforeRendering: function(){
                        //this.getView().byId("idBtn").setIcon("sap-icon://supplier");
                    },
                    onAfterRendering: function(){
                        // $("#idMain--idBtn").fadeOut(3000, function(){
                        //     $("#idMain--idBtn").fadeIn(3000);
                        // });
                    }
                });
});