//internal JS - reusable functions
function spierman(){
    //output function 1
    //alert('Welcome to Web!')

    //output function 2
    //console.log('welcome to JS');

    //output function 3
    document.write('<h3 style="color:blue">Welcome to JS</h3>');
}
function onLogin(){

    //Step 1: get the access of the object of ui control
    //var oUser = document.getElementById("idUn");
    var oPassword = document.getElementById("pwd");
    //Step 2: get the value from that object - chaining in JS
    var sUser = document.getElementById("idUn").value;
    var sPassword = oPassword.value;
    //Step 3: compare the value
    if(sUser === sPassword){
        //Step 4: if value is same change entire DOM to login
        document.write("<h3>Login successful</h3>");
    }else{
        //Step 5: give error
        //alert('Hey amigo! there is an error caused');
        //output function 4
        document.getElementById("msg").innerText = "Hey User, the credentials are wrong!😊";
    }

}
function onMagicJQ(){
    $(".box-title").css("color","white").css("background-color","grey");
}
function onHide(){
    //$(".box").hide();
    $(".box").fadeOut(5000, function(){
        alert("its over");
    });    
}
function onShow(){
    //$(".box").show();
    $(".box").fadeIn(5000);
}
function onAnimate(){
    $("input").animate({
        width: "10px",
        height: "10px"
    }, function(){
        $(this).animate({
            width: "150px",
            height: "30px"
        }, function(){
            onAnimate();
        });
    });
}

function onLoadEmp(){
    $.ajax("https://api.covid19api.com/dayone/country/india",{
        success: function(data){
            for (let i = 0; i < data.length; i++) {
                const element = data[i];
                var text = element.Date + "  ===  " + element.Confirmed;
                onAdd(text);
            }
        },
        error: function(oErr){
            debugger;
        }
    });
}

function onMagic(){
    //Step 1: Get all the elements for the class
    var aElements = document.getElementsByClassName("box-title");
    //Step 2: loop over them and 
    for (let i = 0; i < aElements.length; i++) {
        const element = aElements[i];
        //Step 3: for each element we will change css
        if(element.style.color === "white"){
            element.style.color = "blue";
            element.style.backgroundColor = "coral";
        }else{
            element.style.color = "white";
            element.style.backgroundColor = "black";
        }
        
    }
    
}

function onAdd(text){
    //Step 1: get the content object
    var oContent = document.getElementById("content");
    //Step 2: create a new element
    var oNewElement = document.createElement("h4");
    //Step 3: create a text element with text data
    var oTextNode = document.createTextNode(text);
    //Step 4: add the text element to new element
    oNewElement.appendChild(oTextNode);
    //Step 5: add this new element to the content 
    oContent.appendChild(oNewElement);
}

function asyncProcess(){
    console.log("we start the function and a timer");
    setTimeout(function(){
        console.log("Wow, Now the async process is done, we are in the callback");
    },5000);
    console.log("we finish the function");
}