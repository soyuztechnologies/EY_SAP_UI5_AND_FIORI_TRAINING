const express = require('express')
const app = express()
app.use(express.static('webapp'));

app.get('/', function (req, res) {
  res.send('<h3>Welcome to Node js tutorials</h3>')
})

app.get("/employees", function(req,res){
  res.send([
    {
     "empId": "1",
     "empName": "anubhav",
     "salary": 25000,
     "currency": "INR",
     "joiningDate": "2022-01-01",
     "gender": "M"
   }, 
    {
     "empId": "2",
     "empName": "Ananya",
     "salary": 6900,
     "currency": "EUR",
     "joiningDate": "2022-01-01",
     "gender": "F"
   }
   ]);
})

// app.get("/file", function(req, res){
//   res.sendFile(__dirname + "/webapp/demo.txt");
// });

console.log("server is running on http://localhost:3000");
app.listen(3000)
