sap.ui.define([
    'ey/fin/ar/controller/BaseController'
], function(Controller, MessageBox, Filter, FilterOperator) {
    'use strict';
    return Controller.extend("ey.fin.ar.controller.Empty",{
        
    });
});


