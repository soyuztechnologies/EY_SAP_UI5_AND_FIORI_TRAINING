const reuse = require('./reuse');

console.log("hello Node JS");

var a = 10;
var b = 20;

var result = reuse.addNumbers(a,b);
console.log(result);
var arr = ["abap on hana","sap fiori", "sap btp", "sap rap"];
reuse.countLength(arr);
reuse.printArray(arr)
