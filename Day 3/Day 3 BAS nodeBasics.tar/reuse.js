module.exports = {
    addNumbers: function (x,y){
        return x + y;
    },
    countLength: function (arr){
        console.log("The length is " + arr.length);
    },
    printArray: function (arr){
        for (let i = 0; i < arr.length; i++) {
            const element = arr[i];
            console.log(element);
        }
    }
}