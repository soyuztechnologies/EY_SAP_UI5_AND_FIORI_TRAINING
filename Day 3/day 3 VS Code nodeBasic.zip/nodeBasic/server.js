const express = require('express')
const app = express()

app.get('/', function (req, res) {
  res.send('<h3>Welcome to Node js tutorials</h3>')
})

console.log("server is running on http://localhost:3000");
app.listen(3000)
